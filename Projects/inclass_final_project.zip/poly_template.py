from OO_complex import *

class Polynomial:

    def __init__(self, coefficients):
        pass

    def add(self, other):
        pass

    def val(self, v):
        pass
    
    def mul(self, other):
        pass
    
    def coeff(self, i):
        pass
    
    def roots(self):
        pass

    def __call__(self, v):
        pass

    def __add__(self, other):
        pass

    def __mul__(self, other):
        pass

    def __str__(self):
        pass
    
