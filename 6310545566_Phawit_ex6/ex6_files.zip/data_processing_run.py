import data_processing as dp

print(dp.cities_data[:10])
print()
print(dp.countries_data[:10])
print()
print(dp.teams_data[:10])
print()
print(dp.players_data[:10])
print()
print(dp.titanic_data[:10])
print()
print(dp.min_max_temp(dp.cities_data))
print()
print(dp.country_list(dp.cities_data))
print()
print(dp.average_country_temp(dp.cities_data))

# your test code for other data_processing functions
