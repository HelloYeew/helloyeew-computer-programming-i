class Complex:
    def __init__(self, re, im):
        """Must check if re and im are of the same types"""
        self.re = re
        self.im = im

    def add(self, m):
        pass
    
    def __add__(self, m):
        pass

    def subtract(self, m):
        pass
    
    def __sub__(self, m):
        pass
    
    def multiply(self, n):
        pass
    
    def __mul__(self, n):
        pass

    def __str__(self):
        pass
