# How to run this program.
- Extract task2.zip
- Run *play_blackjack_multi.py*

Just that!

![Alt text](tenor.gif)